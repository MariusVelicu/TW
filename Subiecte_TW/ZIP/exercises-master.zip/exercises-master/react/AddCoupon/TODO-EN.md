# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` complete the following tasks:
- `AddCoupon` component should be rendered inside `CouponList` component;
- `AddCoupon` component should contain 3 inputs with `id` and `name`: `category`, `discount`, `availability`;
- `AddCoupon` component should contain an input of type `button` with the value `add coupon`, used to trigger `addCoupon` method;
- `AddCoupon` component inside `CouponList` should contain a `props` called `onAdd`;
- When pressing `add coupon` a new item should be displayed in `CouponList` component;