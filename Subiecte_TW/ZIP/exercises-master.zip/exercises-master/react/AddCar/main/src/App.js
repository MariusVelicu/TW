import React, { Component } from 'react';
import { CarList } from './CarList';

class App extends Component {

  render() {
    return (
      <div>
        <CarList />
      </div>
    );
  }
}

export default App;
