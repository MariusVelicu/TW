#Subject 0 (2.5 pts)
#TOPIC: simple

# Dată fiind aplicația dezvoltată cu express, js și html, compltați proiectul astfel încât doar contabilii (accountant) sunt încărcați de pe server și desenați în tabel. Punctaj defalcat:
- Serverul livrează index.html ca resursă statică; (0.5 pts)
- În pagină există un buton cu id-ul `load` pe care se poate da click; (0.5 pts)
- Când se dă click pe load, angajații sunt încărcați de la `http://localhost:8080/employees` utilizând un query parameter  și desenați în tabelul cu id-ul `main`; (0.5 pts)
- Numărul de angajați încărcați este 2; (0.5 pts)
- Ambii angajați sunt contabili. (0.5 pts)
