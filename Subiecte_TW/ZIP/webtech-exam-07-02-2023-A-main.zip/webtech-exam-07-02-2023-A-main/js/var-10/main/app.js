function processString(input){
    // TODO
}

const app = {
    processString: processString
}

module.exports = app