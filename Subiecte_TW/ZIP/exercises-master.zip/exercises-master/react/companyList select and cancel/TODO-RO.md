# Subiect 4
# Tematica: REACT

# Avand urmatoarea aplicatie create folosind `create-react-app`, modificati `Company` si adaugati `CompanyDetails` astfel incat:
- aplicatia se deseneaza corect (0.5 pts);
- `CompanyDetails` are o proprietate numita `item` care contine compania ale carei detalii le afiseaza (0.5 pts);
- `CompanyList` se deseneaza ca o lista de  `Company`, iar fiecare `Company` are un buton cu eticheta `select` (0.5 pts);
- Daca se da click pe butonul select al unui `Company` se deschide afiseaza componenta de detalii (0.5 pts);
- Daca este afisat `CompanyDetails` si se da click pe butonul cancel se afiseaza din nou lista de companii (0.5 pts);
