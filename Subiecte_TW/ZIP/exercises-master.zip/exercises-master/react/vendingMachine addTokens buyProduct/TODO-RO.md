# Subiect 4
# Tematica: REACT

# Avand urmatoarea aplicatie pentru vanzare automata de produse  realizati modificari astfel incat:
- aplicatia se deseneaza corect (0.5 pts)
- incarcati lista de produse din ProductStore la desenarea componentei `VendingMachine` (0.5 pts)
- adaugati componenta `Product` afisati numele, pretul si un buton cu eticheta buy care apeleaza metoda onBuy (0.5 pts)
- implementati metoda addTokens care incrementeaza numarul de token cu 1 la fiecare apasare de buton (0.5 pts)
- implementati metoda buyProduct care scade numarul de tokeni cu pretul produsului cumparat; daca nu sunt suficienti tokeni nu se realizeaza vanzare (0.5 pts)