import DeviceList from './components/DeviceList'

const App = () => {
  return (
    <div>
      <DeviceList />
    </div>
  )
}

export default App
