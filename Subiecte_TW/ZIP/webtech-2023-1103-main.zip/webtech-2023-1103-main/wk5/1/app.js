import { circleArea } from "./util.js"

console.log(circleArea(3))