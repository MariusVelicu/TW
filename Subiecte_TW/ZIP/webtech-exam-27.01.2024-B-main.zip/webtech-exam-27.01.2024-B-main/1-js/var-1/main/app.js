function updateProperty(arr, prop, f) {
    // TODO
}

const app = {
    updateProperty
}

module.exports = app