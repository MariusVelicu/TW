# Subiect 1 (2.5 pts)
# Tematica: Clienți și servere simple

# Dat fiind serverul `app.js` și fișierul `index.html` din directorul `public`:

# Satisfaceți următoarele cerințe:
- Fișierul `index.html`, trebuie sa contina un element de tip `paragraf` cu textul `Webtech app` si sa fie furnizat ca si continut static din directorul `public` (0.5 pts);
- Butoanele cu id-urile `load` si `delete` există în pagină și nu se afla intr-o stare disabled (0.5 pts);
- La apasarea butonului `load` sunt încărcate toate elementele din fisierul `data.json` în tabelul cu id `table` cu un `tr` pentru fiecare element si 3 `td-uri` pentru fiecare proprietate (0.5 pts);
- Input-ul de tip `text` cu id-ul `name` exista in pagina (0.5pts);
- La apasarea butonului `delete` se șterg elementele cu numele prezent în text input-ul cu id-ul `name` (0.5 pts);