# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` add a `Company` component and modify `CompanyList` so that:
- the app renders correctly (0.5 pts);
- `CompanyList` is rendered as a child of `App` (0.5 pts);
- `CompanyList` is rendered as a list of `Company` (0.5 pts);
- `Company` has a property called item containing the company it's supposed to render (0.5 pts);
- `Company` can be deleted via a button with the label `delete` (0.5 pts);
