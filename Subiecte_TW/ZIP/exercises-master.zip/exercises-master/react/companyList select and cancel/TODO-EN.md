# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` modify `Company` component and add `CompanyDetails` so that:
- the app renders correctly (0.5 pts);
- `CompanyList` is rendered as a list of `Company` and each `Company` has a button labeled `select`(0.5 pts);
- `CompanyDetails` has a property called item containing the company whose details it's supposed to render (0.5 pts);
- If the select button is clicked on a `Company` the details component is shown (0.5 pts);
- If the `CompanyDetails` component is shownand the button labeled `cancel` is clicked, the company list is displayed (0.5 pts);