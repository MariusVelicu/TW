const Product = (props) => {
	const { name, price, onBuy } = props
	return (
		<div>
		</div>
	)
}

export default Product