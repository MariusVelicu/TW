# Obiectiv: Să se modifice în locul marcat fișierele astfel încât să treacă testele

# Instrucțiuni de rulare
1. Din directorul `main` rulați `npm install`
2. Din directorul `main` rulați `npm test`