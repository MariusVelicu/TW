# Subiect 1 (2.5 pts)
# Tematica: Clienți și servere simple

# Dat fiind serverul `app.js` și fișierul `index.html` din directorul `public` directory:

# Satisfaceți următoarele cerințe:
- fișierul `index.html`, care conține textul `A simple app` este livrat de server ca conținut static (0.5 pts);
- butonul cu id-ul `load` există în pagină și se poate da click pe el(0.5 pts);
- când se dă click pe butonul cu id-ul `load` se cere lista de `cars` de pe server; mașinile cu culoare `red` sunt încărcate în tabelul cu id `main` cu un `tr` pentru fiecare (0.5 pts);
- tabelul conține câte un `tr` pentru fiecare mașină încărcată (0.5 pts);
- sunt afișate doar mașini cu culoarea `red` (0.5 pts);

