# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` complete the following tasks:
- `AddProduct` component should be rendered inside `ProductList` component;
- `AddProduct` component should contain 3 inputs with `id` and `name`: `name`, `category`, `price`;
- `AddProduct` component should contain an input of type `button` with the value `add product`, used to trigger `addProduct` method;
- `AddProduct` component inside `ProductList` should contain a `props` called `onAdd`;
- When pressing `add product` a new item should be displayed in `ProductList` component;