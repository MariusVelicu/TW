#Subject 0 (2.5 pts)
#TOPIC: simple

# Having the following application developed using express, js and html complete the project so that only accountants are loaded from the server and drawn as rows in a table. Points breakdown:
- The server delivers index.html as a static resource; (0.5 pts)
- The plage loads a series of employees,and contains a form; (0.5 pts)
- When the `addBtn` button is clicked an empty employee is added; (0.5 pts)
- The form on the page contains input fields for the characteristics of an employee with the ids `nameInput` and `jobInput`; (0.5 pts)
- An employee can be added and it shows up in the table. (0.5 pts)
