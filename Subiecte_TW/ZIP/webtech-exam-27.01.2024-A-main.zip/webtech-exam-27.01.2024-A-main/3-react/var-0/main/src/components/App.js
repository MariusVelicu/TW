// TODO
function App () {
  return (
    <div>
      <h1>
        A list of employees
      </h1>
      <EmployeeList />
    </div>
  ) 
}

export default App
