export function circleArea (r) {
  return Math.PI * r * r
}