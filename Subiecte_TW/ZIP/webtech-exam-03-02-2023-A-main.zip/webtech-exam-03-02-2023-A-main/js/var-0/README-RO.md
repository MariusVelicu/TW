# Instructiuni

# Obiectiv : Modificati `app.js` in locul marcat pentru a satiface testele

# Pasi pentru a rula testele
1. Intrati in directorul main `main` ruland `cd main`
2. Instalati dependentele ruland `npm i`
3. Testati aplicatia ruland `npm test`