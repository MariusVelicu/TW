function generator(initialState) {
    // TODO
}

const app = {
    generator
}

module.exports = app