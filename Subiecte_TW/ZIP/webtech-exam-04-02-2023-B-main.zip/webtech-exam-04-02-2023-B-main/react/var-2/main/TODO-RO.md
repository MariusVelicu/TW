# Subiect 4
# Tematica: REACT

# Avand urmatoarea aplicatie create folosind `create-react-app`, modificati `Company` si adaugati `CompanyDetails` astfel incat:
- aplicatia se deseneaza corect (0.5 pts);
- aplicatia deseneaza o lista de companii cu butoane de select (0.5 pts);
- o companie primeste ca parametru un `item` si o functie `onSelect` (0.5 pts);
- Daca se da click pe butonul select al unei companii se deschide afiseaza componenta de detalii (0.5 pts);
- Daca este afisat `CompanyDetails` si se da click pe butonul cancel se afiseaza din nou lista de companii (0.5 pts);
