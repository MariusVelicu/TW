# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` modify `Company` component and modify `CompanyList` so that:
- the app renders correctly (0.5 pts);
- a company list with edit buttons is rendered(0.5 pts);
- If the edit button is clicked on a company it goes into edit mode (0.5 pts);
- If a company is in edit mode and the button labeled `cancel` is clicked, it goes into view mode (0.5 pts);
- A company can be saved and the changes are reflected in the company list (0.5 pts);