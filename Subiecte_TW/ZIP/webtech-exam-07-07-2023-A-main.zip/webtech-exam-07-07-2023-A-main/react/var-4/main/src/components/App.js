import VendingMachine from './VendingMachine'

const App = () => {
  return (
    <div>
      Vending Machine
      <VendingMachine />
    </div>
  )
}

export default App
