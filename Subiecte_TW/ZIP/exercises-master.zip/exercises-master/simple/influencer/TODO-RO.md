# Subiect 1 (2.5 pts)
# Tematica: Clienți și servere simple

# Dat fiind serverul `app.js` și fișierul `index.html` din directorul `public` directory:

# Satisfaceți următoarele cerințe:
- fișierul `index.html`, care conține textul `A simple app` este livrat de server ca conținut static (0.5 pts);
- fișierul `profil.json` livrat de catre server respecta structura descrisa in test (0.5 pts)
- pagina `index.html` conține titlu de rang 1 cu textul `Profil Influencer` (0.5 pts)
- detaliile profiluli (name, instagram, youtube) sunt afisate in paragrafe separate in div-ul cu id=content (0.5 pts) 
- butonul convert afiseaza numarul de urmaritori pe instagram in milioane (ex: 5M); operatia se realizeaza doar pe client (0.5 pts)

