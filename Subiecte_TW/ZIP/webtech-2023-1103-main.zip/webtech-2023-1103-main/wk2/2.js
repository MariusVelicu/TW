function concatenate(a) {
  return a.join(' ')
}

let sampleArray = ['one', 'two', 'three']

console.log(concatenate(sampleArray))