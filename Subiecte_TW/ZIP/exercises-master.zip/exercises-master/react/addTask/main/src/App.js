import React from 'react';
import TaskList from './TaskList';

export default class App extends React.Component{

  render() {
    return (
      <div>
        <TaskList />
      </div>
    );
  }
}
