// TODO

const app = {
    Person, 
    Student
}

module.exports = app