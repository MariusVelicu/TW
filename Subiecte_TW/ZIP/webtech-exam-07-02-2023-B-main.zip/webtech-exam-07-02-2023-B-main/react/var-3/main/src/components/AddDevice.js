import { useState } from 'react';

const AddDevice = (props) => {
	const { onAdd } = props
	const [name, setName] = useState('')
	const [price, setPrice] = useState(0)

	return (
		<div>
		
		</div>
	)
}

export default AddDevice