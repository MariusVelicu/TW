import CompanyList from './CompanyList'

const App = () => {
  return (
    <div>
      A list of companies
      <CompanyList />
    </div>
  )
}

export default App
