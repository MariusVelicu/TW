# Objective: Modify the files in the marked places in order for the project to pass the tests

# Instrucțiuni de rulare
1. From the `main` directory run `npm install`
2. From the `main` directory run `npm test`