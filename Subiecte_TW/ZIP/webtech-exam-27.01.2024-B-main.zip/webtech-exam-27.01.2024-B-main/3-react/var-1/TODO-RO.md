# Subiect 3 (2.5 pts)
# TOPIC: REACT

# Dată fiind aplicația modificati codul sursă astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Se desenează o componentă TaskList; (0.5 pts)
- În componenta TaskList, elementele cu prioritate `low` au culoarea `lightgreen`; (0.5 pts)
- Task-urile încep în starea `not done`;(0.5 pts)
- Dând click pe butonul `toggle done` pe un task, acesta schimbă între stările `not done` și `done`. (0.5 pts)