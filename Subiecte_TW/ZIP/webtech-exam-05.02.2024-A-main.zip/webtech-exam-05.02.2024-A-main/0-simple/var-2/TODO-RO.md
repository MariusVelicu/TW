#Subject 0 (2.5 pts)
#TOPIC: simple

# Dată fiind aplicația dezvoltată cu express, js și html, compltați proiectul astfel încât doar contabilii (accountant) sunt încărcați de pe server și desenați în tabel. Punctaj defalcat:
- Serverul livrează index.html ca resursă statică; (0.5 pts)
- Pagina încarcă o serie de angajați, iar în pagină există un formular; (0.5 pts)
- Când se dă click pe butonul cu id-ul `addBtn`, este adăugat un angajat vid în tabelul cu id-ul `main`; (0.5 pts)
- Formularul conține câmpuri de input pentru caracteristicile unui angajat, cu id-urile `nameInput` și `jobInput`; (0.5 pts)
- Se poate adăuga un angajat, iar acesta apare în tabel. (0.5 pts)
