# Subject 3 (2.5 pts)
# TOPIC: REACT

# Given the application which permits editing of a `task`, modify the source code such that:

- The application renders without error; (0.5 pts)
- For each `task` a `select` button is rendered which allows the `task` to be selected; (0.5 pts)
- On clicking `select` the selected row becomes an editable form and while clicking `cancel` it returns to view mode; (0.5 pts)
- `description` can be modified for a `task`;(0.5 pts)
- `priority` can be modified for a `task`. (0.5 pts)