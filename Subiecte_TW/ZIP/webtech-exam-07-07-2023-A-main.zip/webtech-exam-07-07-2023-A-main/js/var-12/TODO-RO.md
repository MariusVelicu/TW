# Subiect 2 (2.5 pts)
# Tematica: Javascript

# Avand definită clasa `Shape` rezolvați următoarele taskuri:

- Dacă `Shape` este instanțiată direct și este apelată metoda `area`, se va arunca un obiect `Error`  cu mesajul `not implemented`; (0.5 pts)
- Se va defini clasă `Square` care extinde `Shape`; Un `Square` poate fi instanțiat pe baza unui obiect cu o proprietate `width`; (0.5 pts)
- Dat fiind un `Square`, se va calcula corect aria acestuia; (0.5 pts)
- Se va defini clasă `Circle` care extinde `Shape`; Un `Circle` poate fi instanțiat pe baza unui obiect cu o proprietate `radius`; Dat fiind un `Circle`, se va calcula corect aria acestuia; (0.5 pts)
- Se va defini clasă `Rectangle` care extinde `Shape`; Un `Rectangle` poate fi instanțiat pe baza unui obiect cu o proprietate `width` și o proprietate `height`; Dat fiind un `Rectangle`, se va calcula corect aria acestuia; (0.5 pts)