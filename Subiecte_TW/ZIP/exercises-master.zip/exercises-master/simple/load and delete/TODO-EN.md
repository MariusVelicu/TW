# Subject 1 (2.5 pts)
# Tematica: Client-Server Simple

# Having the files `app.js` and `index.html` from `public` directory:

# Complete the following tasks:
- `index.html` file should be delivered as static content from the `public` directory. It shoudl contain a `paragraph` element with `Webtech app` text (0.5 pts);
- Buttons with `ids` `load` and `delete` should exist in the `html` page and they are not disabled (0.5 pts);
- Clicking the button with the id `load` should load all the elements from `data.json` file and render them inside the table with id `table` with a `tr` for each element and 3 `tds` for each property (0.5 pts);
- Text input with id `name` should exist in the html page (0.5 pts);
- When pressing the button with the id `delete`, the application should erase the element with `name` property equals with the value introduced in the text input with the id `name` (0.5 pts);