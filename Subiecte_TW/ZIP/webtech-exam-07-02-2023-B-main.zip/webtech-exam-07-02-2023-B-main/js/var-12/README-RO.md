# Instrucțiuni

Pentru a testa aplicația, rulați `npm test` în linia de comandă în directorul de proiect.