# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` modify `Company` component and add `CompanyDetails` so that:
- the app renders correctly (0.5 pts);
- the application renders a list of companies with select buttons (0.5 pts);
- a company receives as parameters an `item` and an `onSelect` function (0.5 pts);
- If the select button is clicked on a `Company` the details component is shown (0.5 pts);
- If the `CompanyDetails` component is shownand the button labeled `cancel` is clicked, the company list is displayed (0.5 pts);