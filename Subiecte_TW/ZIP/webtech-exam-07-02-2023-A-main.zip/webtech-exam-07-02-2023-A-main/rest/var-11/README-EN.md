# Instructions

To test the app run `npm test` in the command line in the project folder. 
To run the app independently run `npm start` in the command line in the project folder.