function bowdlerize(input, dictionary){
}

const app = {
    bowdlerize
};

module.exports = app;