function circleArea (r) {
  return Math.PI * r * r
}
module.exports = {
  circleArea
}