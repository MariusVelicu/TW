# Subject 2 (2.5 pts)
# TOPIC: Javascript

# Having the `function processString(input)`, which initially splits the `input` string into `tokens` based on space, complete the following tasks:

- If any `token` is not a number, the function should throw an `Error` 
- If `token` is not a number, the function should throw an `Error` with the message `Item is not a number`; (0.5 pts)
- If `input` is empty the function should return 100; (0.5 pts)
- Odd `tokens` are ignored; (0.5 pts)
- The function should return 100 minus the sum of all even `tokens`; (0.5 pts)