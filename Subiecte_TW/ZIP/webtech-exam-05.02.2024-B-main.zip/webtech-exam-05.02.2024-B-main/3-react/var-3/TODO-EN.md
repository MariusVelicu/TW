# Subject 3 (2.5 pts)
# TOPIC: REACT

# Given the application which permits editing of a `task`, modify the source code such that:

- The application renders without error; (0.5 pts)
- For each `task` a `select` button is rendered which allows the `task` to be selected; (0.5 pts)
- On clicking the `select` button, under the table an editing form is drawn; the form is not drawn if nothing is selected; (0.5 pts)
- A `task` can be selected;(0.5 pts)
- The `description` of a `task` can be modified. (0.5 pts)