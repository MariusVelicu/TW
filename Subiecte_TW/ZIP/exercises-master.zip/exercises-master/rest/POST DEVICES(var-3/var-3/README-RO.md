# Instructiuni

# Obiectiv : Modificati fisierele din directorul `src` pentru a satiface testele

# Pasi pentru a rula testele
1. Intrati in directorul main `main` ruland `cd main`
2. Instalati dependentele ruland `npm i`
3. Schimbați utilzatorul și parola bazei de date în app.js
4. Testati aplicatia ruland `npm test`