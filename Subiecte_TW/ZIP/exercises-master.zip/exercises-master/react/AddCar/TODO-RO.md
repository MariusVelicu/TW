# Subiect 4
# Tematica: REACT

# Avand urmatoarea apliatie create folosind `create-react-app`, completati urmatoarele taskuri:
- Componenta `AddCar` trebuie adaugata in interiorul componentei `CarList`;
- Componenta `AddCar` trebuie sa contina 3 elemente de tip input cu `id-ul` si `name-ul`: `make`, `model`, `price`;
- Componenta `AddCar` trebuie sa contina un element input de tip buton `button` cu valoarea `add car`, folosit pentru a apela metoda `addCar`;
- Componenta `AddCar` din interiorul componentei `CarList` trebuie sa contina in `props` metoda `onAdd`;
- La apasarea butonului `add car` un nou element trebuie afisat in componenta `CarList`;