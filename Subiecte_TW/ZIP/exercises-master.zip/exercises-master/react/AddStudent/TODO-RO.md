# Subiect 4
# Tematica: REACT

# Avand urmatoarea apliatie create folosind `create-react-app`, completati urmatoarele taskuri:
- Componenta `AddStudent` trebuie adaugata in interiorul componentei `StudentList`;
- Componenta `AddStudent` trebuie sa contina 3 elemente de tip input cu `id-ul` si `name-ul`: `name`, `surname`, `age`;
- Componenta `AddStudent` trebuie sa contina un element input de tip buton `button` cu valoarea `add student`, folosit pentru a apela metoda `addStudent`;
- Componenta `AddStudent` din interiorul componentei `StudentList` trebuie sa contina in `props` metoda `onAdd`;
- La apasarea butonului `add student` un nou element trebuie afisat in componenta `StudentList`;