# Subject 4
# Topic: REACT
# Having the following application created with `create-react-app` complete the following tasks:
- `AddBook` component should be rendered inside `BookList` component;
- `AddBook` component should contain 3 inputs with the following properties `id` and `name` having the following values: `book-title`, `book-type`, `book-price`;
- `AddBook` component should contain an input of type `button` with the `value` property `add book`, used to trigger `handleAdd` method;
- `AddBook` component inside `BookList` should contain a `props` called `itemAdded `;
- When pressing `add book` button a new item should be displayed in `BookList` component; 