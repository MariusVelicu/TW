const checkDivisiblity = function (n, d) {
  if (n % d) {
    return false
  } else {
    return true
  }
}

console.log(checkDivisiblity(8, 2))