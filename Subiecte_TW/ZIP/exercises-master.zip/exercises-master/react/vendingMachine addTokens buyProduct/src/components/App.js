import React, { Component } from 'react'
import VendingMachine from './VendingMachine'

class App extends Component {
  render() {
    return (
      <div>
      	Vending Machine
      	<VendingMachine />
      </div>
    )
  }
}

export default App
