# Subiect 4
# Tematica: REACT

# Avand urmatoarea apliatie create folosind `create-react-app`, completati urmatoarele taskuri:
- Componenta `AddCoupon` trebuie adaugata in interiorul componentei `CouponList`;
- Componenta `AddCoupon` trebuie sa contina 3 elemente de tip input cu `id-ul` si `name-ul`: `category`, `discount`, `availability`;
- Componenta `AddCoupon` trebuie sa contina un element input de tip buton `button` cu valoarea `add coupon`, folosit pentru a apela metoda `addCoupon`;
- Componenta `AddCoupon` din interiorul componentei `CouponList` trebuie sa contina in `props` metoda `onAdd`;
- La apasarea butonului `add coupon` un nou element trebuie afisat in componenta `CouponList`;