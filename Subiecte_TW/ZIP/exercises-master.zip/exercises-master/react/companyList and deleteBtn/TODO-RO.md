# Subiect 4
# Tematica: REACT

# Avand urmatoarea aplicatie create folosind `create-react-app`, adaugati o componenta `Company` astfel incat:
- aplicatia se deseneaza corect (0.5 pts);
- `CompanyList` este desenata ca un copil al lui `App` (0.5 pts);
- `CompanyList` se deseneaza ca o lista de  `Company` (0.5 pts);
- `Company` are o proprietate numita `item` care contine compania pe care o afiseaza (0.5 pts);
- `Company` poate fi sters prin apasarea unui buton cu eticheta `delete` (0.5 pts);
