# Subject 4
# Topic: REACT

# Having the following automatic vending machine created with `create-react-app` modify it so that:
- the app renders correctly (0.5 pts);
- the list of products is loaded from the ProducStore when `VendingMachine` is rendered(0.5 pts)
- add the component `Product` to display the name, price and a button with the label buy that calls the onBuy method recieved by props (0.5 pts)
- implement addTokens that increments the number of tokens by 1 at each press of the add token button (0.5 pts)
- implement buyProduct thet substracts the tokens with the price of the product; if there are not enough tokens nothing happens (0.5 pts)
