# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` complete the following tasks:
- `AddStudent` component should be rendered inside `StudentList` component;
- `AddStudent` component should contain 3 inputs with `id` and `name`: `name`, `surname`, `age`;
- `AddStudent` component should contain an input of type `button` with the value `add student`, used to trigger `addStudent` method;
- `AddStudent` component inside `StudentList` should contain a `props` called `onAdd`;
- When pressing `add student` a new item should be displayed in `StudentList` component;