import TaskList from './TaskList'

function App () {
  return (
    <div>
      <h1>
        A list of employees
      </h1>
      <TaskList />
    </div>
  ) 
}

export default App
