# Subiect 1 (2.5 pts)
# Tematica: Clienți și servere simple

# Dat fiind serverul `server.js` și fișierul `index.html` din directorul `public` directory:

# Satisfaceți următoarele cerințe:
- fișierul `index.html`, care conține textul `A simple app` este livrat de server ca conținut static (0.5 pts);
- butonul cu id-ul `del` există în pagină și se poate da click pe el(0.5 pts);
- la încărcarea paginii sunt încărcate toate elementele în tabelul cu id `main` cu un `tr` pentru fiecare (0.5 pts);
- când se dă click pe butonul `del` se șterg elementele cu numele prezent în text input-ul cu id-ul `name` (0.5 pts);
- elementele cu numele selectat pentru ștergere nu mai apar în tabel (0.5 pts);