function Home() {
  return (
    <div>
      i am the home page
    </div>
  );
}

export default Home;
