# Subiectul 1 (2.5 pts)
# Tematica: Javascript

# Implementați două tipuri obiectuale: `Person` și `Student` unde:
- `Student` moștenește `Person`;
- `Person` are două proprietăți, `firstName` și `lastName` și o metodă numită `walk` fără parametri, care returnează un string;
- Pe lângă ce moștenește, `Student` are o proprietate `faculty` și o metodă `study` fără parametri, care returnează un string.

# Punctaj defalcat:
- `Person` este un tip obiectual; (0.5 pts)
- `Student` este un tip obiectual; (0.5 pts)
- `Student` moștenește `Person`; (0.5 pts)
- Se poate apela corect metoda `study` pe un obiect de tip `Student`; (0.5 pts)
- Se poate apela corect metoda `walk` pe un obiect de tip `Student`. (0.5 pts)