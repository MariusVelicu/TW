#Subject 0 (2.5 pts)
#TOPIC: simple

# Dată fiind aplicația dezvoltată cu express, js și html, compltați proiectul astfel încât doar contabilii (accountant) sunt încărcați de pe server și desenați în tabel. Punctaj defalcat:
- Serverul livrează index.html ca resursă statică; (0.5 pts)
- Există un buton cu id-ul `sortAscBtn` în pagină și se poate da click pe el; (0.5 pts)
- Există un buton cu id-ul `sortDescBtn` în pagină și se poate da click pe el; (0.5 pts)
- La click pe butonul `sortAscBtn`, liniile din tabelul `main` sunt sortate ascendent după nume; (0.5 pts)
- La click pe butonul `sortDescBtn`, liniile din tabelul `main` sunt sortate descendent după nume; (0.5 pts)
