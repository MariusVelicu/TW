# Instrucțiuni

Pentru a testa aplicația, rulați `npm test` în linia de comandă în directorul de proiect. 
Pentru a porni independent aplicația, rulați `npm start` în linia de comandă în directorul de proiect.