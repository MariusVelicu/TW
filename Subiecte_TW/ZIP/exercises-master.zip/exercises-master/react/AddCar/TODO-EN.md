# Subject 4
# Topic: REACT

# Having the following application created with `create-react-app` complete the following tasks:
- `AddCar` component should be rendered inside `CarList` component;
- `AddCar` component should contain 3 inputs with `id` and `name`: `make`, `model`, `price`;
- `AddCar` component should contain an input of type `button` with the value `add car`, used to trigger `addCar` method;
- `AddCar` component inside `CarList` should contain a `props` called `onAdd`;
- When pressing `add car` a new item should be displayed in `CarList` component;