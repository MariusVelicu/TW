import React, { Component } from 'react'
import CompanyList from './CompanyList'

class App extends Component {
  render() {
    return (
      <div>
      	A list of companies
      	<CompanyList />
      </div>
    )
  }
}

export default App
