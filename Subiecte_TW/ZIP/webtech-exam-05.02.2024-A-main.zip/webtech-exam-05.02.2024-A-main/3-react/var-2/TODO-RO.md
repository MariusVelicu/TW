# Subiect 3 (2.5 pts)
# TOPIC: REACT

# Dată fiind o aplicație care permite editarea unei liste de `task` modificati codul sursă astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Se pentru fiecare `task` un buton `select` care permite selectarea lui; (0.5 pts)
- La apăsarea butonului `select` rândul selectat devine un formular editabil, iar din mod editabil prin apăsarea butonului `cancel` se revine în mod view; (0.5 pts)
- Se poate modifica `description` pentru un `task`;(0.5 pts)
- Se poate modifica `priority` pentru un `task`. (0.5 pts)