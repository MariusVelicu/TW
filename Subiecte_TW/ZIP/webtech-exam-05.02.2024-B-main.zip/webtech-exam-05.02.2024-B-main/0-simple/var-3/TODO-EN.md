#Subject 0 (2.5 pts)
#TOPIC: simple

# Having the following application developed using express, js and html complete the project so that only accountants are loaded from the server and drawn as rows in a table. Points breakdown:
- The server delivers index.html as a static resource; (0.5 pts)
- There is a button with the id `sortAscBtn` on the page and it can be clicked; (0.5 pts)
- There is a button with the id `sortDescBtn` on the page and it can be clicked; (0.5 pts)
- When clicking `sortAscBtn`, lines in the table `main` are sorted by name in ascendent order; (0.5 pts)
- When clicking `sortDescBtn`, lines in the table `main` are sorted by name in descendent order; (0.5 pts)

