# Subject 3 (2.5 pts)
# TOPIC: REACT

# Having the following application developed using React complete the project so that :

- The application renders without crashing; (0.5 pts)
- A TaskList component is rendered; (0.5 pts)
- In the TaskList, low priority items are `lightgreen` in color; (0.5 pts)
- By default, tasks are `not done`;(0.5 pts)
- On clicking the `toggle done` button on a task, it toggles between `not done` and `done`. (0.5 pts)