// TODO
function App () {
  return (
    <div>
      <h1>
        A list of tasks
      </h1>
      <TaskList />
    </div>
  ) 
}

export default App
