const { circleArea } = require('./util.js')

console.log(circleArea(3))