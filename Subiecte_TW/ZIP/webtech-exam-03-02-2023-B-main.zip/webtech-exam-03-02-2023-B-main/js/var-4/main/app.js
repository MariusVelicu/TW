function removeOrderItem(orderInfo, position){
    
}

const app = {
    removeOrderItem
};

module.exports = app;