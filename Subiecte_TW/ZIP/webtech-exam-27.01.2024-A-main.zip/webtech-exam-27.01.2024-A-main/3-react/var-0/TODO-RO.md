# Subject 3 (2.5 pts)
# Subiect: REACT

# Dată fiind aplicația dezvoltată cu React completați codul astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Aplicația desenează o componentă EmployeeList; (0.5 pts)
- Componenta EmployeeFromnu adaugă o înregistrare vidă dacă se dă click pe butonul `add` fără a completa formularul; (0.5 pts)
- Dat fiind că input-urile pentru proprietățile unui employee au id-urile `name`, `job` and `salary` iar butonul are valoarea `add` se poate adăuga cu succes un angajat;(0.5 pts)
- Formularul aplică condiția `salary>1000`. Dacă salariul nu satisface condiția, butonul `add` este disabled. (0.5 pts)