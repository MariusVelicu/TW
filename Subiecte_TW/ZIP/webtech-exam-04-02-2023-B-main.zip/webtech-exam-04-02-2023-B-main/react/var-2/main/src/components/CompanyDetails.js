const CompanyDetails = (props) => {

}

export default CompanyDetails
