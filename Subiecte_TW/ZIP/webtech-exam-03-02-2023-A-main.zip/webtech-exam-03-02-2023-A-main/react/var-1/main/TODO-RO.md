# Subiect 4
# Tematica: REACT

# Avand urmatoarea aplicatie create folosind `create-react-app`, modificati `Company` astfel incat:
- aplicatia se deseneaza corect (0.5 pts);
- aplicatia deseneaza o lista de companii cu butoane de editare (0.5 pts);
- daca se da click pe butonul edit al unei aceasta trece in mod de editare (0.5 pts);
- daca in mod edit se da click pe butonul cancel al unui companii aceasta trece in mod view (0.5 pts);
- Se poate salva o companie, iar schimbarea se reflecta in lista de companii (0.5 pts);
