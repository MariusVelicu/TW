# Subject 1 (2.5 pts)
# TOPIC: Basic servers and clients

# Given the server `app.js` and the file `index.html` in the `public` directory:

# Complete the following tasks:
- the static content in public directory is delivered by the server(0.5 pts);
-  `profil.json` has the structure required in the test (0.5 pts)
- the page `index.html` has a first rang title containing the text `Profil Influencer` (0.5 pts)
- profile details (name, instagram, youtube) are displayed in separate paragraphs in the div-ul with id=content (0.5 pts) 
- the button with will convert instagram followers into milions (ex 5M); this is executed only on the client side  (0.5 pts)


