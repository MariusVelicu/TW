# Subiect 2 (2.5 pts)
# TOPIC: Javascript

# Dată fiind funcția `function processString(input)`, care inițial tokenizează string-ul `input` în mai multe `tokens` separate de spațiu, rezolvați următoarele cerințe:

- Dacă oricare `token` nu este un `number` sau un `Number`, funcția ar trebui să arunce `Error` 
- Dacă oricare `token` nu este un `number` sau un `Number`, funcția ar trebui să arunce `Error` cu mesajul `Item is not a number`; (0.5 pts)
- Dacă `input` are lungime 0 funcția ar trebui să returneze 100; (0.5 pts)
- Token-urile `impare` sunt ignorate; (0.5 pts)
- Funcția returnează 100 minus suma tuturor `token`-urilor pare; (0.5 pts)