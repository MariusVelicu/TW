# Subiect 3 (2.5 pts)
# TOPIC: REACT

# Dată fiind aplicația modificati codul sursă astfel încât:

- Aplicația se desenează fără eroare; (0.5 pts)
- Se pentru fiecare `task` un buton `select` care permite selectarea lui; (0.5 pts)
- La apăsarea butonului `select` apare un formular de editare a rândului sub tabel; formularul nu se desenează dacă nu este selectat niciun rând; (0.5 pts)
- Se poate selecta un `task`;(0.5 pts)
- Se poate modifica `description` pentru un `task`. (0.5 pts)