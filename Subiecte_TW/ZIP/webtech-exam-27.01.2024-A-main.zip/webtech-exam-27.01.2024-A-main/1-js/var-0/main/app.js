function objectMap(o, f) {
    // TODO
}

const app = {
    objectMap
}

module.exports = app